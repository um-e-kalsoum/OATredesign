#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Bio::SeqIO;
use File::Path qw(make_path);
use File::Util;
use File::Basename qw(basename);

my ( $fastaPath, $outDir, $l);

GetOptions(
	'i|input=s' => \$fastaPath,
	'o|out-dir=s' => \$outDir,
	'l|length=i' => \$l
);

sub usage {
	print <<USAGE;
fasta_segmenter.pl Takes fasta file or a driectory containing fasta files (.faa or .ffn) and segments the seq into separate entries
				   of minimum length (l) in a new fasta file.

Usage:	[option]
    -i | --input	Path to input .faa or .ffn file or directory containing .faa or .ffn files
    -o | --out-dir	Path to output directory. Creates directory if it doesn't exist
    -l | --length	Minimum length of seq segments

Examples:
perl fasta_segmenter.pl -i input -o dir -l 1000

USAGE
	exit;
}

usage() unless $fastaPath && $outDir && $l;

if (-d $fastaPath) {
	opendir(DIR0, $fastaPath) or die "Can't open $fastaPath: $!\n";
	while (defined(my $fastaName = readdir(DIR0))) {
		next unless $fastaName =~ /\.ffn|\.faa$/;
        segment($outDir, join(File::Util->SL, $fastaPath, $fastaName), $l);
	}
	closedir(DIR0);
} elsif (-e $fastaPath && $fastaPath =~ /\.ffn|\.faa$/) {
    segment($outDir, $fastaPath, $l);
} else {
	print "Input file(s) do not meet requirements.\n\n";
	usage()
}

sub segment {
	my ($outDir, $fastaName, $l) = @_;

	my $fasta_object = Bio::SeqIO->new(-file => "<$fastaName", -format => 'fasta');
	
	$outDir =~ s/[\/\\]+$//;
    if (!-e $outDir) { make_path($outDir); }
    if (!-e $outDir) { die "Can't find output directory \"$outDir\"\n"; }
    $outDir .= File::Util->SL;

    my $base = basename($fastaName);

	open (OUT, ">", join("/", $outDir, join("_$l"."_bp_segments.", split(/\./, $base))));
	
	while (my $seq_object = $fasta_object->next_seq) {

		#segment the seq
		my ( $start, $end, $counter, $segStart ) = ( 0, 0, 0, 0 );
		my $seqLength = $seq_object->length;
		while ($seqLength > $segStart) {
			$counter++;
			my $seqToPrint;
			#if greater than twice fragmentation size, print fragmentation size, else print whole thing
			if ($seqLength >= (2 * $l) + $segStart) {				
				$seqToPrint = substr($seq_object->seq, $segStart, $l);	
				$segStart = $segStart + $l;			
			} else {
				$seqToPrint = substr($seq_object->seq, $segStart);
				$segStart = $seqLength + 1;
			}
			#update start/end values
			$start = $end + 1;
			$end = $end + length($seqToPrint);
			
			#print em out
			print OUT ">".$seq_object->id." ".$seq_object->desc."|Segment=$counter|Segment Length=".length($seqToPrint)."|Start=$start|End=$end\n";
			print OUT "$seqToPrint\n";
		}
	}	
	close OUT;
}
	
	